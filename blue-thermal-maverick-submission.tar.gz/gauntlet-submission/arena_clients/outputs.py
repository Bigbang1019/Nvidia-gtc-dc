"""Console summary and local copy of an image submission.

Both helpers run after the submission is final and must never change its
outcome: they never raise, never touch the network, and do no slow work.
An agent that crashed after submitting would exit non-zero, and an attempt
could look failed even though its answer counted.
"""

from __future__ import annotations

import base64
import re
from pathlib import Path
from typing import Any

_IMAGE_EXTENSIONS = {"image/png": "png", "image/jpeg": "jpg", "image/webp": "webp"}


def missing_tools_note(result: Any) -> str:
    """One line naming required tools the run skipped, or "" if none.

    Practice sets quality to 0 and accepted to false when a required tool
    was not called, and lists them in ``score.missing_required_tools``.
    """
    try:
        score = result.get("score") if isinstance(result, dict) else getattr(result, "score", None)
        missing = score.get("missing_required_tools") if isinstance(score, dict) else None
        if isinstance(missing, (list, tuple)) and missing:
            return "Missing required tools: " + ", ".join(str(name) for name in missing)
        return ""
    except Exception:
        return ""


def submission_summary_lines(result: Any) -> list[str]:
    """Accepted / status / score lines for a submit result, without image data.

    Accepts the REST ``SubmitResult`` or the MCP ``arena.image.submit_edit``
    dict. Image submissions echo the image back (``edited_image`` and
    ``score.output_image_uri``), so the raw result must not be printed.
    """
    try:
        if isinstance(result, dict):
            accepted = result.get("accepted")
            status = result.get("status")
            score = result.get("score")
        else:
            accepted = getattr(result, "accepted", None)
            status = getattr(result, "status", None)
            score = getattr(result, "score", None)
        lines = [f"Accepted: {accepted}"]
        if status:
            lines.append(f"Status: {status}")
        if isinstance(score, dict) and score.get("final_score") is not None:
            lines.append(f"Score: {score['final_score']}")
        note = missing_tools_note(result)
        if note:
            lines.append(note)
        judge_error = score.get("judge_error") if isinstance(score, dict) else None
        if judge_error:
            # Quality is 0 because the judge failed, not because the image was poor.
            lines.append(f"Judge error: {judge_error} (quality 0 until the image can be judged)")
        return lines
    except Exception as exc:
        return [f"Submission result unavailable ({type(exc).__name__})"]


def save_submitted_image(agent_id: str, image_uri: Any, root: Path) -> str:
    """Best effort: write the submitted image to ``root/outputs/``.

    Only inline ``data:image/...;base64`` images are written; a URL is
    skipped rather than downloaded. Returns a one-line status to print.
    """
    try:
        header, _, data = str(image_uri or "").partition(",")
        if not header.startswith("data:image/") or ";base64" not in header:
            return "not saved (not an inline image)"
        mime = header[len("data:"):].split(";")[0]
        extension = _IMAGE_EXTENSIONS.get(mime, "img")
        safe_id = re.sub(r"[^A-Za-z0-9_-]", "_", str(agent_id))[:64] or "agent"
        out_dir = Path(root) / "outputs"
        out_dir.mkdir(exist_ok=True)
        path = out_dir / f"{safe_id}-submission.{extension}"
        path.write_bytes(base64.b64decode(data, validate=True))
        return f"saved to {path}"
    except Exception as exc:
        return f"not saved ({type(exc).__name__})"


def read_edit_reference(uri: str) -> bytes | None:
    """Read a bounded inline reference or the organizer's public asset origin."""
    from urllib.parse import urlsplit
    import requests

    cap = 5 * 1024 * 1024
    try:
        if uri.startswith("data:image/"):
            header, _, body = uri.partition(",")
            if ";base64" not in header or len(body) > 4 * ((cap + 2) // 3):
                return None
            return base64.b64decode(body, validate=True)
        url = urlsplit(uri)
        if url.scheme != "https" or url.netloc != "assets.ngc.nvidia.com":
            return None
        with requests.get(uri, stream=True, timeout=(8, 8), allow_redirects=False) as response:
            if response.status_code != 200 or not response.headers.get("Content-Type", "").startswith("image/"):
                return None
            data = bytearray()
            for chunk in response.iter_content(65536):
                data.extend(chunk)
                if len(data) > cap:
                    return None
            return bytes(data)
    except (ValueError, OSError, requests.RequestException):
        return None


_HUE_CENTERS = {"red": 0, "orange": 21, "yellow": 43, "green": 85,
                "cyan": 128, "blue": 170, "purple": 198, "pink": 230}


def _requested_color_mask(brief, edited, changes):
    """Localize one explicitly colored addition while retaining edges and shadows."""
    from PIL import ImageChops, ImageFilter

    # Filtering by one hue cannot preserve the other parts of a compound request.
    action = re.split(r"\b(?:while|and (?:keep|preserve|leave))\b", brief.lower(), maxsplit=1)[0]
    if re.search(r"\b(and|plus|along with|as well as|with (?:a|an|another))\b|[,;]", action):
        return changes
    colors = set(re.findall(r"\b(red|orange|yellow|green|cyan|blue|purple|pink)\b", brief.lower()))
    if len(colors) != 1 or not re.search(r"\b(add|give|put|place|attach)\b", brief, re.I):
        return changes
    hue, saturation, value = edited.convert("HSV").split()
    center = _HUE_CENTERS[colors.pop()]
    hue = hue.point(lambda v: 255 if min(abs(v - center), 256 - abs(v - center)) <= 23 else 0)
    chroma = ImageChops.darker(hue, saturation.point(lambda v: 255 if v >= 70 else 0))
    chroma = ImageChops.darker(chroma, value.point(lambda v: 255 if v >= 40 else 0))
    seed = ImageChops.darker(chroma, changes)
    near_color = seed.filter(ImageFilter.MaxFilter(9))
    proposed = ImageChops.darker(changes, near_color)
    changed_total = changes.histogram()[255]
    # An object with tiny color accents provides too little evidence for restricting the edit.
    if changed_total and seed.histogram()[255] >= 0.22 * changed_total and proposed.histogram()[255] >= 0.60 * changed_total:
        return proposed
    return changes


def preserve_local_edit(reference: bytes | None, generated: str, brief: str = "") -> str:
    """Restore original pixels outside one spatially isolated edit, if aligned."""
    from io import BytesIO
    from PIL import Image, ImageChops, ImageFilter, ImageOps, ImageStat

    if not reference or not generated.startswith("data:image/"):
        return generated
    try:
        raw = read_edit_reference(generated)
        if raw is None:
            return generated
        with Image.open(BytesIO(reference)) as a, Image.open(BytesIO(raw)) as b:
            if any(im.width * im.height > 8_000_000 for im in (a, b)):
                return generated
            if abs(a.width * b.height / (a.height * b.width) - 1) > 0.01:
                return generated
            source = ImageOps.exif_transpose(a).convert("RGB")
            edited = ImageOps.exif_transpose(b).convert("RGB").resize(source.size, Image.Resampling.LANCZOS)
        if min(source.size) < 64:
            return generated
        sample = source.copy()
        sample.thumbnail((96, 96), Image.Resampling.LANCZOS)
        small_edit = edited.resize(sample.size, Image.Resampling.LANCZOS)
        channels = ImageChops.difference(sample, small_edit).split()
        delta = ImageChops.lighter(ImageChops.lighter(channels[0], channels[1]), channels[2])
        strong = delta.filter(ImageFilter.MedianFilter(3)).point(lambda x: 255 if x >= 36 else 0)
        region = strong.getbbox()
        if region is None:
            return generated
        x0, y0, x1, y1 = region
        fraction = (x1 - x0) * (y1 - y0) / (sample.width * sample.height)
        if not 0.003 < fraction < 0.45:
            return generated
        mask = Image.new("L", sample.size)
        # Keep the entire changed region, including shading and low-contrast details.
        mask.paste(255, region)
        outside = ImageOps.invert(mask.filter(ImageFilter.MaxFilter(7)))
        if outside.getbbox() is None or ImageStat.Stat(delta, outside).mean[0] > 12:
            return generated
        localized = _requested_color_mask(brief, small_edit, strong)
        mask = localized.filter(ImageFilter.MaxFilter(7)).filter(ImageFilter.GaussianBlur(0.8))
        blended = Image.composite(edited, source, mask.resize(source.size, Image.Resampling.BILINEAR))
        data = BytesIO()
        blended.save(data, format="PNG", compress_level=3)
        if data.tell() > 5 * 1024 * 1024:
            return generated
        return "data:image/png;base64," + base64.b64encode(data.getvalue()).decode("ascii")
    except (OSError, ValueError, Image.DecompressionBombError):
        return generated
